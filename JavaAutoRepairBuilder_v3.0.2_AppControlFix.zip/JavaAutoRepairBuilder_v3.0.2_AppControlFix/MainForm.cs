namespace JavaAutoRepairBuilder;

public sealed class MainForm : Form
{
    private readonly TextBox _project = new() { Dock = DockStyle.Fill };
    private readonly TextBox _pythonSource = new() { Dock = DockStyle.Fill };
    private readonly TextBox _migrationOutput = new() { Dock = DockStyle.Fill };
    private readonly ComboBox _model = new() { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDown };
    private readonly TextBox _ollama = new() { Dock = DockStyle.Fill, Text = "http://127.0.0.1:11434" };
    private readonly NumericUpDown _maxLoops = new() { Minimum = 1, Maximum = 50, Value = 30, Dock = DockStyle.Left, Width = 90 };
    private readonly Label _status = new() { AutoSize = true, Text = "Ready" };
    private readonly RichTextBox _log = new() { Dock = DockStyle.Fill, ReadOnly = true, Font = new Font("Consolas", 10), BackColor = Color.FromArgb(25,25,25), ForeColor = Color.Gainsboro };

    private readonly Button _migrate = new() { Text = "PYTHON -> JAVA MIGRATE", Height = 44, Dock = DockStyle.Fill };
    private readonly Button _run = new() { Text = "AUTO BUILD / REPAIR", Height = 44, Dock = DockStyle.Fill };
    private readonly Button _buildOnly = new() { Text = "BUILD ONLY", Height = 44, Dock = DockStyle.Fill };
    private readonly Button _runTest = new() { Text = "RUN OUTPUT TEST", Height = 44, Dock = DockStyle.Fill };
    private readonly Button _createExe = new() { Text = "CREATE EXE", Height = 44, Dock = DockStyle.Fill };
    private readonly Button _buildApk = new() { Text = "BUILD APK", Height = 44, Dock = DockStyle.Fill };
    private readonly Button _stop = new() { Text = "STOP", Height = 44, Dock = DockStyle.Fill, Enabled = false };

    private CancellationTokenSource? _cts;
    private readonly BuildService _buildService = new();
    private readonly OllamaService _ollamaService = new();
    private readonly PackagingService _packaging = new();

    public MainForm()
    {
        Text = "Java Auto Repair Builder v3.0 - Universal LLM Repair Loop";
        Width = 1300;
        Height = 860;
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(980, 640);
        ShowInTaskbar = true;
        WindowState = FormWindowState.Normal;

        // 起動確認用。ここまで到達したことを startup_crash.log と区別できるようにする。
        try
        {
            File.AppendAllText(
                Path.Combine(AppContext.BaseDirectory, "startup_trace.log"),
                $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] MainForm constructor entered{Environment.NewLine}");
        }
        catch { }

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, Padding = new Padding(12) };
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        Controls.Add(root);

        var settings = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 4 };
        settings.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        settings.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        settings.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        settings.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));

        AddProjectRow(settings);
        AddMigrationRows(settings);
        AddOllamaRows(settings);

        var buttons = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 7, Padding = new Padding(0, 8, 0, 8) };
        foreach (int p in new[] { 20, 18, 12, 15, 12, 12, 11 })
            buttons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, p));
        buttons.Controls.Add(_migrate, 0, 0);
        buttons.Controls.Add(_run, 1, 0);
        buttons.Controls.Add(_buildOnly, 2, 0);
        buttons.Controls.Add(_runTest, 3, 0);
        buttons.Controls.Add(_createExe, 4, 0);
        buttons.Controls.Add(_buildApk, 5, 0);
        buttons.Controls.Add(_stop, 6, 0);

        _migrate.Click += async (_, _) => await MigratePythonAsync();
        _run.Click += async (_, _) => await RunPipelineAsync();
        _buildOnly.Click += async (_, _) => await BuildOnlyAsync();
        _runTest.Click += async (_, _) => await RunOutputTestAsync();
        _createExe.Click += async (_, _) => await CreateExeAsync();
        _buildApk.Click += async (_, _) => await BuildApkAsync();
        _stop.Click += (_, _) => _cts?.Cancel();

        var top = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false
        };
        settings.Width = 1240;
        buttons.Width = 1240;
        top.Controls.Add(settings);
        top.Controls.Add(buttons);

        root.Controls.Add(top, 0, 0);
        root.Controls.Add(_log, 0, 1);
        root.Controls.Add(_status, 0, 2);

        Shown += (_, _) =>
        {
            try
            {
                AppendLog("[STARTUP] GUI initialized successfully.");
                SetStatus("Ready");
                File.AppendAllText(
                    Path.Combine(AppContext.BaseDirectory, "startup_trace.log"),
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] MainForm shown{Environment.NewLine}");
            }
            catch { }
        };
    }

    private void AddProjectRow(TableLayoutPanel settings)
    {
        settings.Controls.Add(new Label { Text = "Java Project", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 0);
        settings.Controls.Add(_project, 1, 0);
        var browse = new Button { Text = "Browse...", AutoSize = true };
        browse.Click += (_, _) => BrowseProject();
        settings.Controls.Add(browse, 2, 0);
        var detect = new Button { Text = "Detect", AutoSize = true };
        detect.Click += (_, _) => DetectBuildSystem();
        settings.Controls.Add(detect, 3, 0);
    }

    private void AddMigrationRows(TableLayoutPanel settings)
    {
        settings.Controls.Add(new Label { Text = "Python Source", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 1);
        settings.Controls.Add(_pythonSource, 1, 1);
        var sourceBrowse = new Button { Text = "Select .py...", AutoSize = true };
        sourceBrowse.Click += (_, _) => BrowsePythonSource();
        settings.Controls.Add(sourceBrowse, 2, 1);
        settings.Controls.Add(new Label { Text = "Migration input", AutoSize = true }, 3, 1);

        settings.Controls.Add(new Label { Text = "Java Output", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 2);
        settings.Controls.Add(_migrationOutput, 1, 2);
        var outputBrowse = new Button { Text = "Output...", AutoSize = true };
        outputBrowse.Click += (_, _) => BrowseMigrationOutput();
        settings.Controls.Add(outputBrowse, 2, 2);
        settings.Controls.Add(new Label { Text = "Maven project", AutoSize = true }, 3, 2);
    }

    private void AddOllamaRows(TableLayoutPanel settings)
    {
        settings.Controls.Add(new Label { Text = "Ollama URL", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 3);
        settings.Controls.Add(_ollama, 1, 3);
        var models = new Button { Text = "Load Models", AutoSize = true };
        models.Click += async (_, _) => await LoadModelsAsync();
        settings.Controls.Add(models, 2, 3);
        settings.Controls.Add(new Label { Text = "", AutoSize = true }, 3, 3);

        settings.Controls.Add(new Label { Text = "Model", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 4);
        settings.Controls.Add(_model, 1, 4);
        settings.Controls.Add(new Label { Text = "Max repair loops", AutoSize = true, Anchor = AnchorStyles.Right }, 2, 4);
        settings.Controls.Add(_maxLoops, 3, 4);
    }

    private void BrowseProject()
    {
        using var dlg = new FolderBrowserDialog { Description = "Java project folder" };
        if (dlg.ShowDialog() == DialogResult.OK)
        {
            _project.Text = dlg.SelectedPath;
            DetectBuildSystem();
        }
    }

    private void BrowsePythonSource()
    {
        using var dlg = new OpenFileDialog { Title = "Select Python source", Filter = "Python source (*.py)|*.py|All files (*.*)|*.*" };
        if (dlg.ShowDialog() != DialogResult.OK) return;
        _pythonSource.Text = dlg.FileName;
        if (string.IsNullOrWhiteSpace(_migrationOutput.Text))
        {
            string parent = Path.GetDirectoryName(dlg.FileName) ?? Environment.CurrentDirectory;
            string name = Path.GetFileNameWithoutExtension(dlg.FileName) + "_java";
            _migrationOutput.Text = Path.Combine(parent, name);
        }
    }

    private void BrowseMigrationOutput()
    {
        using var dlg = new FolderBrowserDialog { Description = "Select parent/output folder for migrated Maven project" };
        if (dlg.ShowDialog() == DialogResult.OK) _migrationOutput.Text = dlg.SelectedPath;
    }

    private void DetectBuildSystem()
    {
        if (!Directory.Exists(_project.Text)) { SetStatus("Project folder not found"); return; }
        SetStatus("Detected: " + _buildService.Detect(_project.Text));
    }

    private async Task LoadModelsAsync()
    {
        try
        {
            SetStatus("Loading Ollama models...");
            var models = await _ollamaService.GetModelsAsync(_ollama.Text, CancellationToken.None);
            _model.Items.Clear();
            _model.Items.AddRange(models.Cast<object>().ToArray());
            if (_model.Items.Count > 0) _model.SelectedIndex = 0;
            SetStatus($"Loaded {models.Count} models");
        }
        catch (Exception ex) { AppendLog("[ERROR] " + ex.Message); SetStatus("Ollama connection failed"); }
    }

    private async Task MigratePythonAsync()
    {
        if (!File.Exists(_pythonSource.Text)) { MessageBox.Show("Python .pyファイルを指定してください。"); return; }
        if (string.IsNullOrWhiteSpace(_migrationOutput.Text)) { MessageBox.Show("Java出力フォルダを指定してください。"); return; }
        if (string.IsNullOrWhiteSpace(_model.Text)) { MessageBox.Show("Ollama modelを指定してください。"); return; }

        ToggleRunning(true);
        _cts = new CancellationTokenSource();
        try
        {
            string output = Path.GetFullPath(_migrationOutput.Text);
            var migration = new PythonMigrationService();
            var result = await migration.MigrateAsync(
                _pythonSource.Text,
                output,
                _ollama.Text,
                _model.Text.Trim(),
                (int)_maxLoops.Value,
                _cts.Token,
                AppendLog,
                SetStatus);

            _project.Text = result.ProjectDir;
            AppendLog($"[SUCCESS] Migration project: {result.ProjectDir}");
            AppendLog($"[INFO] Chunks processed: {result.ChunksProcessed}, generated file writes: {result.FilesWritten}");
            SetStatus("Python -> Java migration SUCCESS");
            MessageBox.Show($"Python -> Java migration completed.\n\n{result.ProjectDir}", "Migration completed", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (OperationCanceledException) when (_cts?.IsCancellationRequested == true) { AppendLog("[STOPPED BY USER]"); SetStatus("Stopped"); }
        catch (Exception ex) { AppendLog("[ERROR] " + ex); SetStatus("Migration failed"); MessageBox.Show(ex.Message, "Migration failed", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        finally { ToggleRunning(false); }
    }

    private async Task BuildOnlyAsync()
    {
        if (!ValidateInputs(false)) return;
        ToggleRunning(true);
        _cts = new CancellationTokenSource();
        try
        {
            var system = _buildService.Detect(_project.Text);
            foreach (var stage in system == BuildSystem.Javac
                ? new[] { PipelineStage.Compile }
                : new[] { PipelineStage.Compile, PipelineStage.Test, PipelineStage.Package })
            {
                SetStatus(stage.ToString());
                var result = await _buildService.RunStageAsync(_project.Text, system, stage, _cts.Token, AppendLog);
                if (!result.Success) { AppendLog($"[FAIL] {stage}"); return; }
                AppendLog($"[SUCCESS] {stage}");
            }
            SetStatus("All stages successful");
        }
        catch (OperationCanceledException) when (_cts?.IsCancellationRequested == true) { AppendLog("[STOPPED BY USER]"); SetStatus("Stopped"); }
        catch (Exception ex) { AppendLog("[ERROR] " + ex); SetStatus("Error"); }
        finally { ToggleRunning(false); }
    }

    private async Task RunOutputTestAsync()
    {
        if (!ValidateInputs(false)) return;
        ToggleRunning(true);
        _cts = new CancellationTokenSource();
        try
        {
            var system = _buildService.Detect(_project.Text);
            AppendLog("===== RUN OUTPUT TEST =====");
            SetStatus("Running output smoke test...");
            var result = await _packaging.RunSmokeTestAsync(_project.Text, system, _cts.Token, AppendLog, 10);
            if (!result.Success)
            {
                AppendLog("[FAIL] Output test");
                if (!string.IsNullOrWhiteSpace(result.Combined)) AppendLog(result.Combined);
                SetStatus("Output test failed");
                return;
            }
            AppendLog("[SUCCESS] Output test");
            SetStatus("Output test successful");
            MessageBox.Show("Java output smoke test succeeded.", "Test success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (OperationCanceledException) when (_cts?.IsCancellationRequested == true) { AppendLog("[STOPPED BY USER]"); SetStatus("Stopped"); }
        catch (Exception ex) { AppendLog("[ERROR] " + ex); SetStatus("Test failed"); MessageBox.Show(ex.Message, "Test failed", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        finally { ToggleRunning(false); }
    }

    private async Task CreateExeAsync()
    {
        if (!ValidateInputs(false)) return;
        ToggleRunning(true);
        _cts = new CancellationTokenSource();
        try
        {
            var system = _buildService.Detect(_project.Text);
            AppendLog("===== CREATE EXE =====");
            SetStatus("Creating Windows EXE...");
            PackageArtifact artifact = await _packaging.CreateExeAsync(_project.Text, system, _cts.Token, AppendLog);
            AppendLog($"[SUCCESS] EXE: {artifact.FilePath}");
            SetStatus("EXE created");
            MessageBox.Show($"EXE generated successfully.\n\n{artifact.FilePath}", "EXE created", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (OperationCanceledException) when (_cts?.IsCancellationRequested == true) { AppendLog("[STOPPED BY USER]"); SetStatus("Stopped"); }
        catch (Exception ex) { AppendLog("[ERROR] " + ex); SetStatus("EXE creation failed"); MessageBox.Show(ex.Message, "EXE creation failed", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        finally { ToggleRunning(false); }
    }

    private async Task BuildApkAsync()
    {
        if (!Directory.Exists(_project.Text)) { MessageBox.Show("Android project folderを指定してください。"); return; }
        ToggleRunning(true);
        _cts = new CancellationTokenSource();
        try
        {
            AppendLog("===== BUILD APK =====");
            SetStatus("Building Android debug APK...");
            PackageArtifact artifact = await _packaging.BuildApkAsync(_project.Text, _cts.Token, AppendLog);
            AppendLog($"[SUCCESS] APK: {artifact.FilePath}");
            SetStatus("APK created");
            MessageBox.Show($"APK generated successfully.\n\n{artifact.FilePath}", "APK created", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (OperationCanceledException) when (_cts?.IsCancellationRequested == true) { AppendLog("[STOPPED BY USER]"); SetStatus("Stopped"); }
        catch (Exception ex) { AppendLog("[ERROR] " + ex); SetStatus("APK build failed"); MessageBox.Show(ex.Message, "APK build failed", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        finally { ToggleRunning(false); }
    }

    private async Task RunPipelineAsync()
    {
        if (!ValidateInputs(true)) return;
        ToggleRunning(true);
        _cts = new CancellationTokenSource();
        try
        {
            var engine = new RepairEngine { MaxRepairLoops = (int)_maxLoops.Value, SameErrorStopCount = 0, MaxAiAttemptsPerFile = 4 };
            await engine.RunAsync(_project.Text, _ollama.Text, _model.Text.Trim(), _cts.Token,
                AppendLog,
                (loop, stage) => SetStatus($"{stage} | Repair {loop}/{_maxLoops.Value}"));
            SetStatus("SUCCESS: compile -> test -> package");
            MessageBox.Show("Java project pipeline completed successfully.\nCompile -> Test -> Package", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (OperationCanceledException) when (_cts?.IsCancellationRequested == true) { AppendLog("[STOPPED BY USER]"); SetStatus("Stopped"); }
        catch (Exception ex) { AppendLog("[ERROR] " + ex); SetStatus("Failed"); MessageBox.Show(ex.Message, "Pipeline stopped", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        finally { ToggleRunning(false); }
    }

    private bool ValidateInputs(bool requireModel)
    {
        if (!Directory.Exists(_project.Text)) { MessageBox.Show("Java project folderを指定してください。"); return false; }
        if (_buildService.Detect(_project.Text) == BuildSystem.Unknown) { MessageBox.Show("Java build systemを検出できません。"); return false; }
        if (requireModel && string.IsNullOrWhiteSpace(_model.Text)) { MessageBox.Show("Ollama modelを指定してください。"); return false; }
        return true;
    }

    private void ToggleRunning(bool running)
    {
        _migrate.Enabled = !running;
        _run.Enabled = !running;
        _buildOnly.Enabled = !running;
        _runTest.Enabled = !running;
        _createExe.Enabled = !running;
        _buildApk.Enabled = !running;
        _stop.Enabled = running;
    }

    private void AppendLog(string text)
    {
        if (InvokeRequired) { BeginInvoke(() => AppendLog(text)); return; }
        _log.AppendText($"[{DateTime.Now:HH:mm:ss}] {text}{Environment.NewLine}");
        _log.SelectionStart = _log.TextLength;
        _log.ScrollToCaret();
    }

    private void SetStatus(string text)
    {
        if (InvokeRequired) { BeginInvoke(() => SetStatus(text)); return; }
        _status.Text = text;
    }
}
