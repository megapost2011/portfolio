using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;

namespace JavaAutoRepairBuilder;

public sealed class BuildService
{
    public BuildSystem Detect(string projectDir)
    {
        if (IsAndroidProject(projectDir)) return BuildSystem.AndroidGradle;
        if (File.Exists(Path.Combine(projectDir, "pom.xml"))) return BuildSystem.Maven;
        if (File.Exists(Path.Combine(projectDir, "gradlew.bat"))) return BuildSystem.GradleWrapper;
        if (File.Exists(Path.Combine(projectDir, "build.gradle")) || File.Exists(Path.Combine(projectDir, "build.gradle.kts"))) return BuildSystem.Gradle;
        if (SourceFileFilter.EnumerateJavaFiles(projectDir).Any()) return BuildSystem.Javac;
        return BuildSystem.Unknown;
    }

    public async Task<ProcessResult> RunStageAsync(string projectDir, BuildSystem system, PipelineStage stage, CancellationToken token, Action<string>? onLine = null)
    {
        return system switch
        {
            BuildSystem.Maven => await RunMavenAsync(projectDir, stage, token, onLine),
            BuildSystem.GradleWrapper => await RunGradleAsync(projectDir, true, stage, token, onLine),
            BuildSystem.Gradle => await RunGradleAsync(projectDir, false, stage, token, onLine),
            BuildSystem.AndroidGradle => await RunAndroidGradleAsync(projectDir, stage, token, onLine),
            BuildSystem.Javac => stage == PipelineStage.Compile
                ? await RunJavacAsync(projectDir, token, onLine)
                : new ProcessResult(0, $"{stage} skipped for direct javac mode.", ""),
            _ => new ProcessResult(-1, "", "Unknown build system")
        };
    }


    public static bool IsAndroidProject(string projectDir)
    {
        try
        {
            var candidates = new[]
            {
                Path.Combine(projectDir, "app", "build.gradle"),
                Path.Combine(projectDir, "app", "build.gradle.kts"),
                Path.Combine(projectDir, "build.gradle"),
                Path.Combine(projectDir, "build.gradle.kts")
            };
            foreach (string f in candidates.Where(File.Exists))
            {
                string text = File.ReadAllText(f);
                if (text.Contains("com.android.application", StringComparison.OrdinalIgnoreCase)) return true;
            }
        }
        catch { }
        return false;
    }

    private Task<ProcessResult> RunAndroidGradleAsync(string dir, PipelineStage stage, CancellationToken token, Action<string>? onLine)
    {
        string wrapper = Path.Combine(dir, "gradlew.bat");
        string exe = File.Exists(wrapper) ? wrapper : "gradle";
        string args = stage switch
        {
            PipelineStage.Compile => "assembleDebug",
            PipelineStage.Test => "testDebugUnitTest",
            PipelineStage.Package => "assembleDebug",
            _ => "assembleDebug"
        };
        return RunProcessAsync(exe, args, dir, token, onLine);
    }

    private Task<ProcessResult> RunMavenAsync(string dir, PipelineStage stage, CancellationToken token, Action<string>? onLine)
    {
        string args = stage switch
        {
            PipelineStage.Compile => "clean compile",
            PipelineStage.Test => "test",
            PipelineStage.Package => "package -DskipTests",
            _ => "compile"
        };
        return RunProcessAsync("mvn.cmd", args, dir, token, onLine);
    }

    private Task<ProcessResult> RunGradleAsync(string dir, bool wrapper, PipelineStage stage, CancellationToken token, Action<string>? onLine)
    {
        string exe = wrapper ? Path.Combine(dir, "gradlew.bat") : "gradle";
        string args = stage switch
        {
            PipelineStage.Compile => "classes",
            PipelineStage.Test => "test",
            PipelineStage.Package => "build -x test",
            _ => "build"
        };
        return RunProcessAsync(exe, args, dir, token, onLine);
    }

    private async Task<ProcessResult> RunJavacAsync(string dir, CancellationToken token, Action<string>? onLine)
    {
        var files = SourceFileFilter.EnumerateJavaFiles(dir).ToList();
        if (files.Count == 0) return new ProcessResult(-1, "", "No Java files found.");
        string outputDir = Path.Combine(dir, ".javac-out");
        Directory.CreateDirectory(outputDir);
        string argFile = Path.Combine(dir, ".javac-sources.txt");

        // javac @argfile treats backslash as an escape character inside quoted arguments.
        // Writing Windows paths such as "E:\\Work\\Main.java" therefore destroys the
        // backslashes (E:WorkMain.java).  Use forward slashes, which javac accepts on Windows.
        static string JavacPath(string path) => Path.GetFullPath(path).Replace('\\', '/');

        await File.WriteAllLinesAsync(
            argFile,
            files.Select(f => $"\"{JavacPath(f)}\""),
            new UTF8Encoding(false),
            token);

        string javacArgs =
            $"-J-Duser.language=en -J-Duser.country=US " +
            $"-encoding UTF-8 -d \"{JavacPath(outputDir)}\" @\"{JavacPath(argFile)}\"";

        return await RunProcessAsync("javac.exe", javacArgs, dir, token, onLine);
    }

    public List<RepairTarget> ExtractRepairTargets(string projectDir, string output)
    {
        var result = new Dictionary<string, StringBuilder>(StringComparer.OrdinalIgnoreCase);

        // javac/Maven compiler style: .../Foo.java:[12,4] ... OR Foo.java:12: error...
        var patterns = new[]
        {
            new Regex(@"(?<file>(?:[A-Za-z]:)?[^\r\n\[\]:]*?\.java):\[(?<line>\d+),(?<col>\d+)\]", RegexOptions.IgnoreCase),
            new Regex(@"(?<file>(?:[A-Za-z]:)?[^\r\n:]*?\.java):(?<line>\d+):", RegexOptions.IgnoreCase),
            new Regex(@"(?<file>(?:[A-Za-z]:)?[^\r\n]*?\.java)\s*:\s*\[", RegexOptions.IgnoreCase)
        };

        foreach (string line in output.Replace("\r", "").Split('\n'))
        {
            foreach (var rx in patterns)
            {
                var m = rx.Match(line);
                if (!m.Success) continue;
                string raw = m.Groups["file"].Value.Trim();
                string resolved = ResolveJavaPath(projectDir, raw);
                if (!File.Exists(resolved) || SourceFileFilter.IsExcluded(projectDir, resolved)) continue;
                if (!result.TryGetValue(resolved, out var sb))
                {
                    sb = new StringBuilder();
                    result[resolved] = sb;
                }
                sb.AppendLine(line);
                break;
            }
        }

        // Surefire/JUnit failures often list class names, not source paths.
        if (result.Count == 0)
        {
            var classMatches = Regex.Matches(output, @"(?:Tests run:|ERROR|FAILURE).*|(?<class>[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)+)\.[A-Za-z_$][\w$]*:", RegexOptions.Multiline);
            foreach (Match m in classMatches)
            {
                if (!m.Groups["class"].Success) continue;
                string className = m.Groups["class"].Value.Split('$')[0];
                string fileName = className.Split('.').Last() + ".java";
                string? path = SourceFileFilter.FindJavaFile(projectDir, fileName);
                if (path != null && !result.ContainsKey(path)) result[path] = new StringBuilder(output);
            }
        }

        return result.Select(kv => new RepairTarget(kv.Key, kv.Value.Length > 0 ? kv.Value.ToString() : output)).ToList();
    }

    public List<RepairTarget> GetFallbackRepairTargets(string projectDir, string output, int maxTargets = 5)
    {
        var all = SourceFileFilter.EnumerateJavaFiles(projectDir)
            .Where(File.Exists)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (all.Count == 0) return new List<RepairTarget>();

        var scored = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        foreach (string file in all) scored[file] = 0;

        // ログ中に現れる Foo.java を拾う。
        foreach (Match m in Regex.Matches(output, @"(?<name>[A-Za-z_$][A-Za-z0-9_$]*\.java)", RegexOptions.IgnoreCase))
        {
            string name = m.Groups["name"].Value;
            foreach (string file in all.Where(f => Path.GetFileName(f).Equals(name, StringComparison.OrdinalIgnoreCase)))
                scored[file] += 100;
        }

        // cannot find symbol: class Foo / symbol: variable foo などの識別子を、ソース内の出現で関連付ける。
        var symbols = new HashSet<string>(StringComparer.Ordinal);
        foreach (Match m in Regex.Matches(output,
                     @"(?:symbol\s*:\s*(?:class|interface|variable|method)\s+|cannot find symbol[^\r\n]*\b)(?<sym>[A-Za-z_$][A-Za-z0-9_$]*)",
                     RegexOptions.IgnoreCase))
        {
            if (m.Groups["sym"].Success) symbols.Add(m.Groups["sym"].Value);
        }

        if (symbols.Count > 0)
        {
            foreach (string file in all)
            {
                try
                {
                    string text = File.ReadAllText(file);
                    foreach (string sym in symbols)
                        if (Regex.IsMatch(text, @"\b" + Regex.Escape(sym) + @"\b")) scored[file] += 15;
                }
                catch { }
            }
        }

        // package ... does not exist は import を持つソースを優先。
        foreach (Match m in Regex.Matches(output,
                     @"package\s+(?<pkg>[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)+)\s+does not exist",
                     RegexOptions.IgnoreCase))
        {
            string pkg = m.Groups["pkg"].Value;
            foreach (string file in all)
            {
                try
                {
                    string text = File.ReadAllText(file);
                    if (text.Contains("import " + pkg, StringComparison.Ordinal)) scored[file] += 35;
                }
                catch { }
            }
        }

        // 1ファイルプロジェクトなら確実にそのファイルを修復対象とする。
        if (all.Count == 1) scored[all[0]] += 500;

        // 何も手掛かりがなければ、最近更新されたJavaを候補にする。
        if (scored.Values.All(v => v == 0))
        {
            foreach (string file in all.OrderByDescending(File.GetLastWriteTimeUtc).Take(Math.Max(1, maxTargets)))
                scored[file] += 1;
        }

        return scored
            .Where(kv => kv.Value > 0)
            .OrderByDescending(kv => kv.Value)
            .ThenByDescending(kv => File.GetLastWriteTimeUtc(kv.Key))
            .Take(Math.Max(1, maxTargets))
            .Select(kv => new RepairTarget(kv.Key, output))
            .ToList();
    }

    private static string ResolveJavaPath(string projectDir, string raw)
    {
        raw = raw.Trim().Trim('"');
        if (Path.IsPathRooted(raw))
        {
            string rooted = Path.GetFullPath(raw);
            return SourceFileFilter.IsExcluded(projectDir, rooted) ? string.Empty : rooted;
        }
        string p = Path.GetFullPath(Path.Combine(projectDir, raw));
        if (File.Exists(p)) return p;
        string fileName = Path.GetFileName(raw);
        return SourceFileFilter.FindJavaFile(projectDir, fileName) ?? p;
    }

    private static async Task<ProcessResult> RunProcessAsync(string fileName, string args, string workingDir, CancellationToken token, Action<string>? onLine)
    {
        var psi = new ProcessStartInfo
        {
            FileName = fileName,
            Arguments = args,
            WorkingDirectory = workingDir,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8
        };

        using var process = new Process { StartInfo = psi, EnableRaisingEvents = true };
        var stdout = new StringBuilder();
        var stderr = new StringBuilder();

        process.OutputDataReceived += (_, e) => { if (e.Data != null) { stdout.AppendLine(e.Data); onLine?.Invoke(e.Data); } };
        process.ErrorDataReceived += (_, e) => { if (e.Data != null) { stderr.AppendLine(e.Data); onLine?.Invoke(e.Data); } };

        try
        {
            process.Start();
            process.BeginOutputReadLine();
            process.BeginErrorReadLine();
            using var registration = token.Register(() =>
            {
                try { if (!process.HasExited) process.Kill(true); } catch { }
            });
            await process.WaitForExitAsync(token);
            return new ProcessResult(process.ExitCode, stdout.ToString(), stderr.ToString());
        }
        catch (OperationCanceledException) { throw; }
        catch (Exception ex)
        {
            return new ProcessResult(-1, stdout.ToString(), stderr + Environment.NewLine + ex.Message);
        }
    }
}
