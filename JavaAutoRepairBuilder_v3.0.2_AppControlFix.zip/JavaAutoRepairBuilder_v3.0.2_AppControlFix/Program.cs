using System.Diagnostics;
using System.Text;

namespace JavaAutoRepairBuilder;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        string crashLog = Path.Combine(AppContext.BaseDirectory, "startup_crash.log");

        try
        {
            // WinForms の未処理例外を握り潰さず、必ず可視化する。
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += (_, e) => ReportFatal("UI thread exception", e.Exception, crashLog);
            AppDomain.CurrentDomain.UnhandledException += (_, e) =>
            {
                Exception ex = e.ExceptionObject as Exception
                    ?? new Exception(e.ExceptionObject?.ToString() ?? "Unknown AppDomain exception");
                ReportFatal("AppDomain unhandled exception", ex, crashLog);
            };
            TaskScheduler.UnobservedTaskException += (_, e) =>
            {
                ReportFatal("Unobserved task exception", e.Exception, crashLog, showMessageBox: false);
                e.SetObserved();
            };

            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("Java Auto Repair Builder v3.0.1 starting...");
            Console.WriteLine($"BaseDirectory: {AppContext.BaseDirectory}");
            Console.WriteLine($"Runtime: {Environment.Version}");
            Console.WriteLine($"OS: {Environment.OSVersion}");

            ApplicationConfiguration.Initialize();

            using var form = new MainForm();
            form.Shown += (_, _) =>
            {
                try
                {
                    form.WindowState = FormWindowState.Normal;
                    form.ShowInTaskbar = true;
                    form.Activate();
                    form.BringToFront();
                }
                catch { }
            };

            Console.WriteLine("MainForm created. Entering message loop...");
            Application.Run(form);
            Console.WriteLine("Application message loop ended.");
        }
        catch (Exception ex)
        {
            ReportFatal("Startup exception", ex, crashLog);
        }
    }

    private static void ReportFatal(string title, Exception ex, string crashLog, bool showMessageBox = true)
    {
        string text = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {title}\r\n{ex}\r\n";

        try { Console.Error.WriteLine(text); } catch { }
        try { File.AppendAllText(crashLog, text + Environment.NewLine, new UTF8Encoding(false)); } catch { }

        if (showMessageBox)
        {
            try
            {
                MessageBox.Show(
                    text + $"\r\nCrash log:\r\n{crashLog}",
                    "Java Auto Repair Builder - Startup Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            catch { }
        }
    }
}
