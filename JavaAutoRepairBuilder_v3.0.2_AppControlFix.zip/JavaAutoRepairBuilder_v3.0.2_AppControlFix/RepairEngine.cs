using System.Security.Cryptography;
using System.Text;

namespace JavaAutoRepairBuilder;

/// <summary>
/// Build -> diagnose -> LLM repair -> extract -> write -> rebuild を自動反復する。
/// LLMの応答形式不一致だけでは停止しない。停止条件は成功、ユーザーSTOP、最大ループのみ。
/// </summary>
public sealed class RepairEngine
{
    private readonly BuildService _build = new();
    private readonly OllamaService _ollama = new();

    public int MaxRepairLoops { get; set; } = 30;
    public int SameErrorStopCount { get; set; } = 0; // v3: 0 = 同一エラーでは停止しない
    public int MaxAiAttemptsPerFile { get; set; } = 4;
    public int MaxTargetsPerLoop { get; set; } = 5;

    public async Task RunAsync(
        string projectDir,
        string ollamaUrl,
        string model,
        CancellationToken token,
        Action<string> log,
        Action<int, string> progress)
    {
        var system = _build.Detect(projectDir);
        if (system == BuildSystem.Unknown)
            throw new InvalidOperationException("Maven / Gradle / Android Gradle / javac のJavaプロジェクトを検出できませんでした。");

        log($"Build system: {system}");
        log($"Model: {model}");
        log($"Auto repair policy: invalid AI response = retry/continue, same build error = continue, max loops = {MaxRepairLoops}");

        int repairLoop = 0;
        string? previousHash = null;
        int sameCount = 0;

        foreach (var stage in new[] { PipelineStage.Compile, PipelineStage.Test, PipelineStage.Package })
        {
            if (system == BuildSystem.Javac && stage != PipelineStage.Compile) continue;

            while (true)
            {
                token.ThrowIfCancellationRequested();
                progress(repairLoop, stage.ToString());
                log($"===== {stage.ToString().ToUpperInvariant()} =====");

                ProcessResult result = await _build.RunStageAsync(projectDir, system, stage, token, log);
                if (result.Success)
                {
                    log($"[SUCCESS] {stage}");
                    previousHash = null;
                    sameCount = 0;
                    break;
                }

                repairLoop++;
                if (repairLoop > MaxRepairLoops)
                {
                    throw new InvalidOperationException(
                        $"最大修正回数 {MaxRepairLoops} 回に達しました。AI応答形式エラーでは停止していません。" +
                        " 最後のビルドエラーをログから確認してください。");
                }

                string combined = result.Combined;
                string hash = Hash(NormalizeErrorForHash(combined));
                if (hash == previousHash) sameCount++; else sameCount = 1;
                previousHash = hash;

                if (sameCount >= 2)
                    log($"[ESCALATE] 同種エラーが {sameCount} 回継続。停止せず、プロンプトを強化して次の修復を続行します。");

                log($"[REPAIR] loop {repairLoop}/{MaxRepairLoops}");

                var targets = _build.ExtractRepairTargets(projectDir, combined);
                if (targets.Count == 0)
                {
                    log("[WARN] コンパイラログから対象Javaを直接特定できません。フォールバック探索を実行します。");
                    targets = _build.GetFallbackRepairTargets(projectDir, combined, MaxTargetsPerLoop);
                }

                if (targets.Count == 0)
                {
                    // v2ではここでthrowしていた。v3では停止せず次ループへ。
                    log("[WARN] 修復対象を特定できませんでした。このループは変更なしで継続します。");
                    await Task.Delay(250, token);
                    continue;
                }

                bool anyUpdated = false;
                foreach (var target in targets.Take(MaxTargetsPerLoop))
                {
                    token.ThrowIfCancellationRequested();
                    bool updated = await RepairFileAsync(
                        projectDir, target, combined, stage, ollamaUrl, model,
                        repairLoop, sameCount, token, log);
                    anyUpdated |= updated;
                }

                if (!anyUpdated)
                {
                    // LLMが説明文だけ/空/同一コードなどでもPipeline stoppedにしない。
                    log("[WARN] このループでは有効なソース更新を得られませんでした。停止せず次ループへ進みます。");
                    await Task.Delay(300, token);
                }
            }
        }

        log("===== ALL PIPELINE STAGES COMPLETED =====");
    }

    private async Task<bool> RepairFileAsync(
        string projectDir,
        RepairTarget target,
        string fullError,
        PipelineStage stage,
        string ollamaUrl,
        string model,
        int repairLoop,
        int sameErrorCount,
        CancellationToken token,
        Action<string> log)
    {
        if (SourceFileFilter.IsExcluded(projectDir, target.FilePath) || !File.Exists(target.FilePath))
        {
            log($"[SKIP] Excluded/missing repair target: {target.FilePath}");
            return false;
        }

        string source = await File.ReadAllTextAsync(target.FilePath, token);
        string relative = Path.GetRelativePath(projectDir, target.FilePath);
        string sourceHash = Hash(source);

        string backupRoot = Path.Combine(
            projectDir,
            ".java-auto-repair-backup",
            DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") + $"_loop{repairLoop:000}");
        string backupPath = Path.Combine(backupRoot, relative);
        Directory.CreateDirectory(Path.GetDirectoryName(backupPath)!);
        await File.WriteAllTextAsync(backupPath, source, new UTF8Encoding(false), token);
        log($"Backup: {backupPath}");

        string errorForAi = fullError.Length > 40000 ? fullError[^40000..] : fullError;
        string previousProblem = sameErrorCount >= 2
            ? $"同種のbuild errorが{sameErrorCount}回継続しています。前回と同じ修正ではなく、型/import/API/依存関係の根本原因を再検討してください。"
            : "";

        for (int attempt = 1; attempt <= MaxAiAttemptsPerFile; attempt++)
        {
            token.ThrowIfCancellationRequested();
            log($"AI repairing: {relative} | attempt {attempt}/{MaxAiAttemptsPerFile}");

            string raw;
            try
            {
                raw = await _ollama.RepairAsync(
                    ollamaUrl, model, target.FilePath, source, errorForAi, stage, token,
                    attempt, previousProblem);
            }
            catch (OperationCanceledException) when (token.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                previousProblem = "LLM request failed: " + ex.Message;
                log($"[AI RETRY] {previousProblem}");
                if (attempt < MaxAiAttemptsPerFile)
                    await Task.Delay(TimeSpan.FromSeconds(Math.Min(8, attempt * 2)), token);
                continue;
            }

            string rawPath = await SaveRawResponseAsync(projectDir, relative, repairLoop, attempt, raw, token);
            log($"[AI RAW] {rawPath}");

            JavaExtractionResult extracted = JavaResponseExtractor.Extract(raw, target.FilePath);
            if (!extracted.Success)
            {
                previousProblem = extracted.Diagnostic;
                log($"[AI PARSE RETRY] {relative}: {extracted.Diagnostic}");
                continue;
            }

            string repaired = extracted.Code;
            log($"[AI PARSE OK] {extracted.Diagnostic}");

            if (Hash(repaired) == sourceHash)
            {
                previousProblem = "抽出結果が現在ソースと同一で、エラーを修正していません。";
                log($"[AI RETRY] {relative}: {previousProblem}");
                continue;
            }

            if (ContainsObviousOmission(repaired))
            {
                previousProblem = "応答に省略プレースホルダーが含まれています。完全なソース全文が必要です。";
                log($"[AI RETRY] {relative}: {previousProblem}");
                continue;
            }

            // Java構造として最低限成立した候補のみ原本へ反映する。
            await File.WriteAllTextAsync(target.FilePath, repaired, new UTF8Encoding(false), token);
            log($"Updated: {relative} | extractor={extracted.Strategy} | chars={repaired.Length}");
            return true;
        }

        log($"[AI GIVEUP THIS LOOP] {relative}: {MaxAiAttemptsPerFile} 回の応答から安全な修正版を得られませんでした。原本は変更せず、Pipelineは停止しません。");
        return false;
    }

    private static async Task<string> SaveRawResponseAsync(
        string projectDir,
        string relative,
        int loop,
        int attempt,
        string raw,
        CancellationToken token)
    {
        string safeRelative = relative
            .Replace(Path.DirectorySeparatorChar, '_')
            .Replace(Path.AltDirectorySeparatorChar, '_')
            .Replace(':', '_');
        string dir = Path.Combine(projectDir, ".java-auto-repair-raw");
        Directory.CreateDirectory(dir);
        string path = Path.Combine(dir,
            $"{DateTime.Now:yyyyMMdd_HHmmss_fff}_L{loop:000}_A{attempt}_{safeRelative}.txt");
        await File.WriteAllTextAsync(path, raw ?? "", new UTF8Encoding(false), token);
        return path;
    }

    private static bool ContainsObviousOmission(string text)
    {
        string lower = text.ToLowerInvariant();
        string[] markers =
        {
            "... existing code ...",
            "// existing code",
            "/* existing code",
            "// unchanged",
            "rest of the code",
            "remaining code unchanged",
            "省略します",
            "以下省略",
            "残りは同じ",
            "変更なしのコード"
        };
        return markers.Any(lower.Contains);
    }

    private static string NormalizeErrorForHash(string text)
    {
        // タイムスタンプや絶対パス差で同一エラー判定が毎回変わらないよう軽く正規化。
        return text
            .Replace('\r', ' ')
            .Replace("\\", "/")
            .Trim();
    }

    private static string Hash(string text)
    {
        byte[] bytes = SHA256.HashData(Encoding.UTF8.GetBytes(text ?? ""));
        return Convert.ToHexString(bytes);
    }
}
