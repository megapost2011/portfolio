using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;

namespace JavaAutoRepairBuilder;

public sealed class PackagingService
{
    private readonly BuildService _build = new();

    public async Task<ProcessResult> RunSmokeTestAsync(
        string projectDir,
        BuildSystem system,
        CancellationToken token,
        Action<string>? onLine = null,
        int timeoutSeconds = 10)
    {
        if (system == BuildSystem.AndroidGradle)
            return new ProcessResult(-1, "", "Android APKはWindows上で直接実行できません。エミュレータまたは実機で確認してください。");

        string? mainClass = DetectMainClass(projectDir);

        if (system == BuildSystem.Javac)
        {
            if (string.IsNullOrWhiteSpace(mainClass))
                return new ProcessResult(-1, "", "public static void main(String[] args) を持つクラスを検出できませんでした。");

            string classes = Path.Combine(projectDir, ".javac-out");
            if (!Directory.Exists(classes))
            {
                var compile = await _build.RunStageAsync(projectDir, system, PipelineStage.Compile, token, onLine);
                if (!compile.Success) return compile;
            }

            return await RunProcessWithSmokeTimeoutAsync(
                "java.exe",
                $"-cp \"{classes}\" {mainClass}",
                projectDir,
                token,
                onLine,
                timeoutSeconds);
        }

        string? jar = FindRunnableJar(projectDir, system);
        if (jar == null)
            return new ProcessResult(-1, "", "実行可能JARを検出できません。先に Package を成功させてください。");

        return await RunProcessWithSmokeTimeoutAsync(
            "java.exe",
            $"-jar \"{jar}\"",
            projectDir,
            token,
            onLine,
            timeoutSeconds);
    }

    public async Task<PackageArtifact> CreateExeAsync(
        string projectDir,
        BuildSystem system,
        CancellationToken token,
        Action<string>? onLine = null)
    {
        if (system == BuildSystem.AndroidGradle)
            throw new InvalidOperationException("AndroidプロジェクトはEXE化対象ではありません。BUILD APKを使用してください。");

        string? mainClass = DetectMainClass(projectDir);
        string jar;

        if (system == BuildSystem.Javac)
        {
            if (string.IsNullOrWhiteSpace(mainClass))
                throw new InvalidOperationException("main() を持つJavaクラスを検出できませんでした。");

            var compile = await _build.RunStageAsync(projectDir, system, PipelineStage.Compile, token, onLine);
            if (!compile.Success)
                throw new InvalidOperationException("javacコンパイルに失敗したためEXE化できません。\n" + compile.Combined);

            jar = await CreateJarForJavacAsync(projectDir, mainClass, token, onLine);
        }
        else
        {
            var package = await _build.RunStageAsync(projectDir, system, PipelineStage.Package, token, onLine);
            if (!package.Success)
                throw new InvalidOperationException("Packageに失敗したためEXE化できません。\n" + package.Combined);

            jar = FindRunnableJar(projectDir, system)
                ?? throw new InvalidOperationException("Package後のJARを検出できませんでした。");
        }

        string appName = MakeSafeAppName(Path.GetFileName(projectDir.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)));
        if (string.IsNullOrWhiteSpace(appName)) appName = "JavaApplication";

        string work = Path.Combine(projectDir, ".java-auto-package");
        string input = Path.Combine(work, "input");
        string dist = Path.Combine(projectDir, "dist-exe");
        Directory.CreateDirectory(input);
        Directory.CreateDirectory(dist);

        string copiedJar = Path.Combine(input, Path.GetFileName(jar));
        File.Copy(jar, copiedJar, true);

        string? jpackage = FindTool("jpackage.exe");
        if (jpackage == null)
            throw new InvalidOperationException("jpackage.exe が見つかりません。JDK 17/21等のJDKをインストールし、JAVA_HOME/binをPATHへ追加してください。");

        string outputAppDir = Path.Combine(dist, appName);
        if (Directory.Exists(outputAppDir)) Directory.Delete(outputAppDir, true);

        var args = new StringBuilder();
        args.Append("--type app-image ");
        args.Append($"--name \"{appName}\" ");
        args.Append($"--input \"{input}\" ");
        args.Append($"--main-jar \"{Path.GetFileName(copiedJar)}\" ");
        args.Append($"--dest \"{dist}\" ");
        if (!string.IsNullOrWhiteSpace(mainClass)) args.Append($"--main-class \"{mainClass}\" ");
        args.Append("--win-console");

        var result = await RunProcessAsync(jpackage, args.ToString(), projectDir, token, onLine);
        if (!result.Success)
            throw new InvalidOperationException("jpackageによるEXE生成に失敗しました。\n" + result.Combined);

        string exe = Path.Combine(outputAppDir, appName + ".exe");
        if (!File.Exists(exe))
        {
            exe = Directory.EnumerateFiles(outputAppDir, "*.exe", SearchOption.AllDirectories).FirstOrDefault()
                ?? throw new InvalidOperationException("jpackageは成功しましたがEXEを検出できませんでした。");
        }

        return new PackageArtifact("EXE", exe, outputAppDir);
    }

    public async Task<PackageArtifact> BuildApkAsync(
        string projectDir,
        CancellationToken token,
        Action<string>? onLine = null)
    {
        if (!BuildService.IsAndroidProject(projectDir))
            throw new InvalidOperationException("Android Gradleプロジェクトを検出できません。app/build.gradle(.kts) と com.android.application が必要です。");

        string wrapper = Path.Combine(projectDir, "gradlew.bat");
        if (!File.Exists(wrapper))
            throw new InvalidOperationException("gradlew.bat がありません。AndroidプロジェクトのGradle Wrapperが必要です。");

        var result = await RunProcessAsync(wrapper, "assembleDebug", projectDir, token, onLine);
        if (!result.Success)
            throw new InvalidOperationException("APKビルドに失敗しました。\n" + result.Combined);

        var apks = Directory.EnumerateFiles(projectDir, "*.apk", SearchOption.AllDirectories)
            .Where(p => p.Replace('\\', '/').Contains("/build/outputs/apk/", StringComparison.OrdinalIgnoreCase))
            .OrderByDescending(File.GetLastWriteTimeUtc)
            .ToList();

        string apk = apks.FirstOrDefault()
            ?? throw new InvalidOperationException("assembleDebug は成功しましたがAPKファイルを検出できませんでした。");

        return new PackageArtifact("APK", apk, Path.GetDirectoryName(apk)!);
    }

    private async Task<string> CreateJarForJavacAsync(
        string projectDir,
        string mainClass,
        CancellationToken token,
        Action<string>? onLine)
    {
        string classes = Path.Combine(projectDir, ".javac-out");
        string work = Path.Combine(projectDir, ".java-auto-package");
        Directory.CreateDirectory(work);
        string jar = Path.Combine(work, "application.jar");
        if (File.Exists(jar)) File.Delete(jar);

        string? jarTool = FindTool("jar.exe");
        if (jarTool == null)
            throw new InvalidOperationException("jar.exe が見つかりません。JDKのbinをPATHへ追加してください。");

        string args = $"--create --file \"{jar}\" --main-class \"{mainClass}\" -C \"{classes}\" .";
        var result = await RunProcessAsync(jarTool, args, projectDir, token, onLine);
        if (!result.Success)
            throw new InvalidOperationException("JAR生成に失敗しました。\n" + result.Combined);
        return jar;
    }

    public string? DetectMainClass(string projectDir)
    {
        foreach (string file in SourceFileFilter.EnumerateJavaFiles(projectDir))
        {
            string text;
            try { text = File.ReadAllText(file); }
            catch { continue; }

            if (!Regex.IsMatch(text, @"public\s+static\s+void\s+main\s*\(\s*String(?:\s*\[\s*\]|\.\.\.)", RegexOptions.Multiline))
                continue;

            var classMatch = Regex.Match(text, @"\b(?:public\s+)?(?:final\s+)?class\s+(?<name>[A-Za-z_$][\w$]*)");
            if (!classMatch.Success) continue;

            var packageMatch = Regex.Match(text, @"^\s*package\s+(?<pkg>[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*;", RegexOptions.Multiline);
            string name = classMatch.Groups["name"].Value;
            return packageMatch.Success ? packageMatch.Groups["pkg"].Value + "." + name : name;
        }
        return null;
    }

    private static string? FindRunnableJar(string projectDir, BuildSystem system)
    {
        IEnumerable<string> candidates = Enumerable.Empty<string>();
        if (system == BuildSystem.Maven)
        {
            string target = Path.Combine(projectDir, "target");
            if (Directory.Exists(target)) candidates = Directory.EnumerateFiles(target, "*.jar", SearchOption.TopDirectoryOnly);
        }
        else if (system is BuildSystem.Gradle or BuildSystem.GradleWrapper)
        {
            string libs = Path.Combine(projectDir, "build", "libs");
            if (Directory.Exists(libs)) candidates = Directory.EnumerateFiles(libs, "*.jar", SearchOption.TopDirectoryOnly);
        }

        return candidates
            .Where(p => !Path.GetFileName(p).Contains("sources", StringComparison.OrdinalIgnoreCase))
            .Where(p => !Path.GetFileName(p).Contains("javadoc", StringComparison.OrdinalIgnoreCase))
            .Where(p => !Path.GetFileName(p).StartsWith("original-", StringComparison.OrdinalIgnoreCase))
            .OrderByDescending(File.GetLastWriteTimeUtc)
            .FirstOrDefault();
    }

    private static string MakeSafeAppName(string raw)
    {
        string s = Regex.Replace(raw, @"[^A-Za-z0-9._-]", "_");
        return s.Trim('.', '_', '-');
    }

    private static string? FindTool(string exe)
    {
        string? javaHome = Environment.GetEnvironmentVariable("JAVA_HOME");
        if (!string.IsNullOrWhiteSpace(javaHome))
        {
            string candidate = Path.Combine(javaHome, "bin", exe);
            if (File.Exists(candidate)) return candidate;
        }

        string? path = Environment.GetEnvironmentVariable("PATH");
        if (path != null)
        {
            foreach (string part in path.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            {
                try
                {
                    string candidate = Path.Combine(part.Trim('"'), exe);
                    if (File.Exists(candidate)) return candidate;
                }
                catch { }
            }
        }
        return null;
    }

    private static async Task<ProcessResult> RunProcessWithSmokeTimeoutAsync(
        string fileName,
        string args,
        string workingDir,
        CancellationToken token,
        Action<string>? onLine,
        int timeoutSeconds)
    {
        using var linked = CancellationTokenSource.CreateLinkedTokenSource(token);
        var psi = CreateStartInfo(fileName, args, workingDir);
        using var process = new Process { StartInfo = psi, EnableRaisingEvents = true };
        var stdout = new StringBuilder();
        var stderr = new StringBuilder();
        process.OutputDataReceived += (_, e) => { if (e.Data != null) { stdout.AppendLine(e.Data); onLine?.Invoke(e.Data); } };
        process.ErrorDataReceived += (_, e) => { if (e.Data != null) { stderr.AppendLine(e.Data); onLine?.Invoke(e.Data); } };

        try
        {
            process.Start();
            process.BeginOutputReadLine();
            process.BeginErrorReadLine();

            Task wait = process.WaitForExitAsync(linked.Token);
            Task timeout = Task.Delay(TimeSpan.FromSeconds(timeoutSeconds), linked.Token);
            Task done = await Task.WhenAny(wait, timeout);

            if (done == timeout && !process.HasExited)
            {
                onLine?.Invoke($"[SMOKE TEST] {timeoutSeconds}秒間クラッシュせず動作しました。テストのためプロセスを停止します。");
                try { process.Kill(true); } catch { }
                await process.WaitForExitAsync(CancellationToken.None);
                return new ProcessResult(0, stdout + $"\nSmoke test passed for {timeoutSeconds} seconds.", stderr.ToString());
            }

            await wait;
            return new ProcessResult(process.ExitCode, stdout.ToString(), stderr.ToString());
        }
        catch (OperationCanceledException) { throw; }
        catch (Exception ex) { return new ProcessResult(-1, stdout.ToString(), stderr + Environment.NewLine + ex.Message); }
    }

    private static Task<ProcessResult> RunProcessAsync(string fileName, string args, string workingDir, CancellationToken token, Action<string>? onLine)
    {
        return RunProcessCoreAsync(fileName, args, workingDir, token, onLine);
    }

    private static async Task<ProcessResult> RunProcessCoreAsync(string fileName, string args, string workingDir, CancellationToken token, Action<string>? onLine)
    {
        var psi = CreateStartInfo(fileName, args, workingDir);
        using var process = new Process { StartInfo = psi, EnableRaisingEvents = true };
        var stdout = new StringBuilder();
        var stderr = new StringBuilder();
        process.OutputDataReceived += (_, e) => { if (e.Data != null) { stdout.AppendLine(e.Data); onLine?.Invoke(e.Data); } };
        process.ErrorDataReceived += (_, e) => { if (e.Data != null) { stderr.AppendLine(e.Data); onLine?.Invoke(e.Data); } };
        try
        {
            process.Start();
            process.BeginOutputReadLine();
            process.BeginErrorReadLine();
            using var registration = token.Register(() => { try { if (!process.HasExited) process.Kill(true); } catch { } });
            await process.WaitForExitAsync(token);
            return new ProcessResult(process.ExitCode, stdout.ToString(), stderr.ToString());
        }
        catch (OperationCanceledException) { throw; }
        catch (Exception ex) { return new ProcessResult(-1, stdout.ToString(), stderr + Environment.NewLine + ex.Message); }
    }

    private static ProcessStartInfo CreateStartInfo(string fileName, string args, string workingDir) => new()
    {
        FileName = fileName,
        Arguments = args,
        WorkingDirectory = workingDir,
        UseShellExecute = false,
        RedirectStandardOutput = true,
        RedirectStandardError = true,
        CreateNoWindow = true,
        StandardOutputEncoding = Encoding.UTF8,
        StandardErrorEncoding = Encoding.UTF8
    };
}

public sealed record PackageArtifact(string Kind, string FilePath, string OutputDirectory);
