Java Auto Repair Builder v2.0 - Python Migration Edition
=======================================================

Main features
-------------
1. Existing Java auto build/repair loop
   - Maven / Gradle / direct javac / Android Gradle detection
   - compile -> test -> package
   - Ollama error repair
   - backup before overwrite
   - repeated-error stop guard

2. Python -> Java application migration agent (NEW)
   - Select a real .py file directly. Renaming to .java is no longer necessary.
   - Builds a structural digest from imports/classes/functions.
   - Asks Ollama for a shared migration architecture plan.
   - Splits large Python source into chunks instead of sending a huge source in one request.
   - Converts chunks into multiple Java source files using strict file markers.
   - Generates a Maven Java 21 project.
   - Typical mappings: tkinter -> Swing, sqlite3 -> JDBC, requests -> HttpClient,
     pathlib -> java.nio.file, threading -> ExecutorService, PyMuPDF/pypdf -> PDFBox.
   - Automatically runs the existing Maven compile/test/package + AI repair pipeline after migration.
   - MIGRATION_PLAN.txt is saved in the generated project.
   - Raw AI replies that cannot be parsed are kept under .migration-raw.

3. Output functions
   - RUN OUTPUT TEST
   - CREATE EXE via jpackage
   - BUILD APK for an Android Gradle project

Recommended migration workflow
------------------------------
A. Start Ollama and load a coding-capable model with enough context.
B. Select Python Source (.py).
C. Set Java Output to a NEW/empty folder if possible.
D. Press PYTHON -> JAVA MIGRATE.
E. The generated folder becomes the Java Project automatically after success.
F. Then use RUN OUTPUT TEST / CREATE EXE as needed.

Important
---------
- Python -> Java is semantic application migration, not a syntax-only conversion.
- Large GUI/AI/CAD/image applications may need several AI passes and manual verification.
- Native Python packages may not have 1:1 Java equivalents.
- APK conversion is separate: a desktop Maven/Swing project is not automatically an Android APK project.
- The STOP button cancels the current Ollama/build operation.

Build this C# tool
------------------
dotnet clean
dotnet build
dotnet run


=== v2.0.2 Long Request Hotfix ===
- Fixed false "[STOPPED BY USER]" after exactly 30 minutes.
- Root cause: HttpClient.Timeout was 30 minutes; timeout raised OperationCanceledException and UI mislabeled it as user STOP.
- HttpClient global timeout is now infinite; /api/generate uses its own linked 120-minute timeout.
- /api/tags model-list lookup uses a 30-second timeout.
- A real STOP button cancellation is still immediate.
- A generation timeout is now reported as a timeout error, not as user cancellation.
