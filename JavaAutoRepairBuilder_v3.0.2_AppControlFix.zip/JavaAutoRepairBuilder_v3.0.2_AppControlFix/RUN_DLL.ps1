$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

dotnet build
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$dll = Join-Path $PSScriptRoot 'bin\Debug\net8.0-windows\JavaAutoRepairBuilder.dll'
if (!(Test-Path $dll)) { throw "DLL not found: $dll" }

dotnet "$dll"
