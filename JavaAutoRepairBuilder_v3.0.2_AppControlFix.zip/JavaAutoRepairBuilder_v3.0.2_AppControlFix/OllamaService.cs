using System.Net.Http.Json;
using System.Text.Json;

namespace JavaAutoRepairBuilder;

public sealed class OllamaService
{
    private readonly HttpClient _http = new() { Timeout = Timeout.InfiniteTimeSpan };
    private static readonly TimeSpan ModelListTimeout = TimeSpan.FromSeconds(30);
    private static readonly TimeSpan GenerateTimeout = TimeSpan.FromHours(2);

    public async Task<List<string>> GetModelsAsync(string baseUrl, CancellationToken token)
    {
        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(token);
        timeoutCts.CancelAfter(ModelListTimeout);
        try
        {
            using var response = await _http.GetAsync(baseUrl.TrimEnd('/') + "/api/tags", timeoutCts.Token);
            response.EnsureSuccessStatusCode();
            using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync(timeoutCts.Token));
            return doc.RootElement.GetProperty("models").EnumerateArray()
                .Select(x => x.GetProperty("name").GetString())
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Cast<string>().ToList();
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested)
        {
            throw new TimeoutException($"Ollama model-list request timed out after {ModelListTimeout.TotalSeconds:0} seconds.");
        }
    }

    public async Task<string> GenerateAsync(string baseUrl, string model, string prompt, CancellationToken token, double temperature = 0.1)
    {
        var body = new { model, prompt, stream = false, options = new { temperature } };
        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(token);
        timeoutCts.CancelAfter(GenerateTimeout);

        try
        {
            using var response = await _http.PostAsJsonAsync(baseUrl.TrimEnd('/') + "/api/generate", body, timeoutCts.Token);
            response.EnsureSuccessStatusCode();
            using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync(timeoutCts.Token));
            return (doc.RootElement.GetProperty("response").GetString() ?? "").Trim();
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested)
        {
            throw new TimeoutException($"Ollama generation timed out after {GenerateTimeout.TotalMinutes:0} minutes. The STOP button was not pressed.");
        }
    }

    public async Task<string> CreateMigrationPlanAsync(string baseUrl, string model, string sourceName, string digest, string appName, string packageName, CancellationToken token)
    {
        string prompt = $"""
You are a senior Python-to-Java application migration architect.
Create a concrete migration plan for the Python application below.
Target: Java 21, Maven, desktop GUI should prefer Swing unless a library absolutely requires another approach.
Preserve behavior, data formats, SQLite data, HTTP APIs, file IO, background processing and user-visible workflows as much as practical.
For Python-only libraries, select a Java equivalent or describe a small adapter/fallback.
Do not write source code yet. Produce a compact implementation plan listing Java classes, responsibilities, dependency mapping and migration risks.

Source: {sourceName}
Target main class: {packageName}.{appName}

STRUCTURE DIGEST:
{digest}
""";
        return await GenerateAsync(baseUrl, model, prompt, token, 0.1);
    }

    public async Task<string> ConvertPythonChunkAsync(string baseUrl, string model, string sourceName, string appName, string packageName, string plan, string digest, string chunk, int index, int total, CancellationToken token)
    {
        string compactPlan = plan.Length > 14000 ? plan[..14000] : plan;
        string compactDigest = digest.Length > 12000 ? digest[..12000] : digest;
        string prompt = $"""
You are a Python-to-Java application migration agent. Convert the supplied Python chunk into production-oriented Java 21 source that fits the shared migration plan.

Hard rules:
- This is LANGUAGE MIGRATION, not repair of malformed Java.
- Preserve functionality; do not merely comment out features.
- Target Maven Java 21 and package `{packageName}`.
- Desktop tkinter UI should be migrated to Swing.
- sqlite3 -> JDBC (sqlite-jdbc).
- requests -> java.net.http.HttpClient.
- pathlib/os -> java.nio.file APIs.
- threading/queue -> ExecutorService / concurrent collections / SwingUtilities for UI updates.
- PIL/image work -> BufferedImage/ImageIO/Java2D when possible.
- PyMuPDF/pypdf -> Apache PDFBox when possible.
- JSON -> Jackson or JDK APIs.
- CSV -> Apache Commons CSV or JDK APIs.
- If this chunk augments a class produced by an earlier chunk, emit the same file with the additional members; the host will merge versions with another AI pass.
- Never emit Markdown commentary.
- Every generated file MUST be wrapped exactly as:
  <<<FILE:src/main/java/{packageName.Replace('.', '/')}/ClassName.java>>>
  ...file content...
  <<<END_FILE>>>
- pom.xml may be emitted as <<<FILE:pom.xml>>> ... <<<END_FILE>>> only when extra dependencies are truly required.
- Emit only file blocks.

Application: {sourceName}
Main class: {appName}
Chunk: {index}/{total}

MIGRATION PLAN:
{compactPlan}

STRUCTURE DIGEST:
{compactDigest}

PYTHON CHUNK:
{chunk}
""";
        return await GenerateAsync(baseUrl, model, prompt, token, 0.05);
    }

    public async Task<string> MergeGeneratedJavaAsync(string baseUrl, string model, string filePath, string existing, string addition, string plan, CancellationToken token)
    {
        string compactPlan = plan.Length > 8000 ? plan[..8000] : plan;
        string prompt = $"""
Merge two generated versions of the same Java file into one compilable Java 21 source file.
Preserve all non-duplicate fields, methods, nested types and behavior from both versions.
Resolve duplicate imports/methods intelligently. Keep package and public type name stable.
Return Java source only. No Markdown.

FILE: {filePath}
PLAN:
{compactPlan}

EXISTING:
{existing}

NEW CONTENT:
{addition}
""";
        return StripCodeFence(await GenerateAsync(baseUrl, model, prompt, token, 0.05));
    }

    public async Task<string> RepairAsync(
        string baseUrl,
        string model,
        string filePath,
        string source,
        string buildError,
        PipelineStage stage,
        CancellationToken token,
        int attempt = 1,
        string previousResponseProblem = "")
    {
        string stageInstruction = stage == PipelineStage.Test
            ? "JUnit/Maven/Gradleのテスト失敗を修正してください。テスト側に誤りがあればテストを、実装側に誤りがあれば実装を修正してください。"
            : stage == PipelineStage.Package
                ? "Javaのpackage/build失敗を修正してください。ソース側の問題ならソースを修正してください。"
                : "Javaコンパイルエラーを修正してください。";

        string retryNote = attempt <= 1 ? "" : $"""

これは再試行 {attempt} 回目です。
前回応答はツールが安全にJavaソースとして抽出できませんでした、または元ソースと同一でした。
前回問題: {previousResponseProblem}
今回は必ず対象ファイルの完全な修正版を含めてください。
""";

        string prompt = $"""
あなたはJavaの自動ビルド修復エージェントです。
{stageInstruction}

最優先事項:
- BUILD/TEST ERRORを根拠に、対象ファイルを本当にコンパイル可能な方向へ修正する。
- 元機能を削除、スタブ化、TODO化、コメントアウトして誤魔化さない。
- package名とpublic型名は維持する。
- import、型、ジェネリクス、例外、API呼び出し、Javaバージョン差異は必要なら修正する。
- 未定義型や単純なトランスパイル誤りは具体的なJava型へ直す。
- ソース全文を返す。途中省略は禁止。
- Markdown、説明文、JSON、<think>が混ざってもホスト側で抽出可能だが、最も安全なのはJava全文のみを返すこと。
- `... existing code ...`、`省略`、`unchanged` 等でコードを欠落させない。
{retryNote}

対象ファイル:
{filePath}

BUILD/TEST ERROR:
{buildError}

CURRENT SOURCE:
{source}
""";

        // 応答形式はモデルごとに異なるため、ここでは加工せずRAW応答を返す。
        // JavaResponseExtractorがMarkdown/JSON/FILEブロック/<think>等を吸収する。
        return await GenerateAsync(baseUrl, model, prompt, token, 0.05);
    }

    private static string StripCodeFence(string text)
    {
        text = text.Trim();
        if (text.StartsWith("```"))
        {
            int nl = text.IndexOf('\n');
            if (nl >= 0) text = text[(nl + 1)..];
            int end = text.LastIndexOf("```", StringComparison.Ordinal);
            if (end >= 0) text = text[..end];
        }
        return text.Trim();
    }
}
