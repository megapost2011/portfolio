namespace JavaAutoRepairBuilder;

/// <summary>
/// Centralized source-tree filtering.  Files created by this tool and common
/// build/VCS dependency directories must never become compile or repair targets.
/// </summary>
public static class SourceFileFilter
{
    private static readonly HashSet<string> ExcludedDirectoryNames = new(StringComparer.OrdinalIgnoreCase)
    {
        ".java-auto-repair-backup",
        ".javac-out",
        ".java-auto-package",
        "dist-exe",
        "target",
        "build",
        "out",
        ".gradle",
        ".git",
        ".idea",
        ".vscode",
        "node_modules",
        "bin",
        "obj"
    };

    public static bool IsExcluded(string projectDir, string path)
    {
        string root = Path.GetFullPath(projectDir)
            .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        string full = Path.GetFullPath(path);

        if (!full.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)
            && !string.Equals(full, root, StringComparison.OrdinalIgnoreCase))
            return true;

        string relative = Path.GetRelativePath(root, full);
        foreach (string part in relative.Split(new[] { Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar }, StringSplitOptions.RemoveEmptyEntries))
        {
            if (ExcludedDirectoryNames.Contains(part)) return true;
        }

        string name = Path.GetFileName(full);
        return name.Equals(".javac-sources.txt", StringComparison.OrdinalIgnoreCase);
    }

    public static IEnumerable<string> EnumerateJavaFiles(string projectDir)
    {
        if (!Directory.Exists(projectDir)) yield break;

        var pending = new Stack<string>();
        pending.Push(Path.GetFullPath(projectDir));

        while (pending.Count > 0)
        {
            string current = pending.Pop();
            IEnumerable<string> dirs;
            IEnumerable<string> files;

            try
            {
                dirs = Directory.EnumerateDirectories(current);
                files = Directory.EnumerateFiles(current, "*.java", SearchOption.TopDirectoryOnly);
            }
            catch (UnauthorizedAccessException)
            {
                continue;
            }
            catch (DirectoryNotFoundException)
            {
                continue;
            }

            foreach (string file in files)
            {
                if (!IsExcluded(projectDir, file)) yield return file;
            }

            foreach (string dir in dirs)
            {
                if (!IsExcluded(projectDir, dir)) pending.Push(dir);
            }
        }
    }

    public static string? FindJavaFile(string projectDir, string fileName)
    {
        return EnumerateJavaFiles(projectDir)
            .FirstOrDefault(p => string.Equals(Path.GetFileName(p), fileName, StringComparison.OrdinalIgnoreCase));
    }
}
