namespace JavaAutoRepairBuilder;

public enum BuildSystem
{
    Unknown,
    Maven,
    GradleWrapper,
    Gradle,
    AndroidGradle,
    Javac
}

public enum PipelineStage
{
    Compile,
    Test,
    Package
}

public sealed record ProcessResult(int ExitCode, string StdOut, string StdErr)
{
    public bool Success => ExitCode == 0;
    public string Combined => string.Join(Environment.NewLine, new[] { StdOut, StdErr }.Where(x => !string.IsNullOrWhiteSpace(x)));
}

public sealed record RepairTarget(string FilePath, string ErrorText);
