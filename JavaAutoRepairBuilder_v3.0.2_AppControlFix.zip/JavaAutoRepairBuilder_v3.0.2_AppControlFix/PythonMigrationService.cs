using System.Text;
using System.Text.RegularExpressions;

namespace JavaAutoRepairBuilder;

public sealed record PythonMigrationResult(string ProjectDir, int ChunksProcessed, int FilesWritten);

public sealed class PythonMigrationService
{
    private readonly OllamaService _ollama = new();
    private readonly BuildService _build = new();

    public int ChunkCharacterLimit { get; set; } = 18000;

    public async Task<PythonMigrationResult> MigrateAsync(
        string pythonFile,
        string outputDir,
        string ollamaUrl,
        string model,
        int maxRepairLoops,
        CancellationToken token,
        Action<string> log,
        Action<string> status)
    {
        if (!File.Exists(pythonFile)) throw new FileNotFoundException("Python source not found.", pythonFile);
        if (!pythonFile.EndsWith(".py", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Python migration mode requires a .py source file.");
        if (string.IsNullOrWhiteSpace(model)) throw new InvalidOperationException("Ollama model is required.");

        string source = await File.ReadAllTextAsync(pythonFile, token);
        Directory.CreateDirectory(outputDir);

        string appName = SanitizeJavaIdentifier(Path.GetFileNameWithoutExtension(pythonFile));
        if (string.IsNullOrWhiteSpace(appName)) appName = "MigratedPythonApp";
        if (!char.IsUpper(appName[0])) appName = char.ToUpperInvariant(appName[0]) + appName[1..];
        string packageName = "migrated." + ToPackagePart(appName);

        log("===== PYTHON -> JAVA MIGRATION =====");
        log($"Python source: {pythonFile}");
        log($"Output project: {outputDir}");
        log($"Detected source size: {source.Length:N0} chars");

        status("Analyzing Python structure...");
        string digest = BuildStructureDigest(source);
        string plan = await _ollama.CreateMigrationPlanAsync(
            ollamaUrl, model, Path.GetFileName(pythonFile), digest, appName, packageName, token);
        await File.WriteAllTextAsync(Path.Combine(outputDir, "MIGRATION_PLAN.txt"), plan, new UTF8Encoding(false), token);
        log("[OK] Migration plan created.");

        WriteBaseMavenProject(outputDir, appName, packageName);

        var chunks = SplitPythonIntoChunks(source, ChunkCharacterLimit);
        log($"Migration chunks: {chunks.Count}");

        int filesWritten = 0;
        for (int i = 0; i < chunks.Count; i++)
        {
            token.ThrowIfCancellationRequested();
            status($"Migrating Python chunk {i + 1}/{chunks.Count}...");
            log($"===== MIGRATION CHUNK {i + 1}/{chunks.Count} =====");

            string response = await _ollama.ConvertPythonChunkAsync(
                ollamaUrl,
                model,
                Path.GetFileName(pythonFile),
                appName,
                packageName,
                plan,
                digest,
                chunks[i],
                i + 1,
                chunks.Count,
                token);

            var files = ParseFileBlocks(response);
            if (files.Count == 0)
            {
                string rawDir = Path.Combine(outputDir, ".migration-raw");
                Directory.CreateDirectory(rawDir);
                string raw = Path.Combine(rawDir, $"chunk_{i + 1:000}.txt");
                await File.WriteAllTextAsync(raw, response, new UTF8Encoding(false), token);
                log($"[WARN] No file blocks detected. Raw response saved: {raw}");
                continue;
            }

            foreach (var item in files)
            {
                string safeRelative = NormalizeGeneratedPath(item.RelativePath, packageName);
                string fullPath = Path.GetFullPath(Path.Combine(outputDir, safeRelative));
                if (!fullPath.StartsWith(Path.GetFullPath(outputDir), StringComparison.OrdinalIgnoreCase))
                    continue;

                Directory.CreateDirectory(Path.GetDirectoryName(fullPath)!);
                string content = item.Content.Trim();
                if (File.Exists(fullPath) && fullPath.EndsWith(".java", StringComparison.OrdinalIgnoreCase))
                {
                    string existing = await File.ReadAllTextAsync(fullPath, token);
                    if (!string.Equals(existing.Trim(), content, StringComparison.Ordinal))
                    {
                        string merged = await _ollama.MergeGeneratedJavaAsync(
                            ollamaUrl, model, fullPath, existing, content, plan, token);
                        content = merged.Trim();
                    }
                }

                await File.WriteAllTextAsync(fullPath, content + Environment.NewLine, new UTF8Encoding(false), token);
                filesWritten++;
                log($"Generated: {Path.GetRelativePath(outputDir, fullPath)}");
            }
        }

        EnsureMainClass(outputDir, appName, packageName);
        EnsurePom(outputDir, appName, packageName);

        status("Compiling migrated Maven project...");
        log("===== MIGRATED PROJECT BUILD / AUTO REPAIR =====");

        var engine = new RepairEngine
        {
            MaxRepairLoops = Math.Max(1, maxRepairLoops),
            SameErrorStopCount = 3
        };

        await engine.RunAsync(outputDir, ollamaUrl, model, token, log,
            (loop, stage) => status($"{stage} | Repair {loop}/{maxRepairLoops}"));

        status("Python -> Java migration completed.");
        log("===== PYTHON -> JAVA MIGRATION COMPLETED =====");
        return new PythonMigrationResult(outputDir, chunks.Count, filesWritten);
    }

    private static string BuildStructureDigest(string source)
    {
        var lines = source.Replace("\r", "").Split('\n');
        var sb = new StringBuilder();
        sb.AppendLine("Imports / top-level declarations:");
        foreach (string line in lines)
        {
            string t = line.TrimEnd();
            if (Regex.IsMatch(t, @"^(from\s+\S+\s+import\s+|import\s+|class\s+|def\s+|async\s+def\s+|[A-Z][A-Z0-9_]*\s*=)"))
                sb.AppendLine(t.Length > 500 ? t[..500] : t);
        }

        var keywords = new[]
        {
            "tkinter", "sqlite3", "requests", "fitz", "pypdf", "ezdxf", "cv2", "numpy",
            "pytesseract", "ultralytics", "torch", "transformers", "faiss", "litellm", "langmem",
            "threading", "subprocess", "zipfile", "csv", "json"
        };
        sb.AppendLine();
        sb.AppendLine("Detected technologies:");
        foreach (string k in keywords.Where(k => source.Contains(k, StringComparison.OrdinalIgnoreCase)))
            sb.AppendLine("- " + k);

        string result = sb.ToString();
        return result.Length > 24000 ? result[..24000] : result;
    }

    private static List<string> SplitPythonIntoChunks(string source, int limit)
    {
        var lines = source.Replace("\r", "").Split('\n');
        var blocks = new List<string>();
        var current = new StringBuilder();

        foreach (string line in lines)
        {
            bool topLevelBoundary = Regex.IsMatch(line, @"^(class\s+|def\s+|async\s+def\s+)");
            if (topLevelBoundary && current.Length >= limit / 2)
            {
                blocks.Add(current.ToString());
                current.Clear();
            }
            current.AppendLine(line);
            if (current.Length >= limit)
            {
                blocks.Add(current.ToString());
                current.Clear();
            }
        }
        if (current.Length > 0) blocks.Add(current.ToString());
        return blocks.Count == 0 ? new List<string> { source } : blocks;
    }

    private sealed record GeneratedFile(string RelativePath, string Content);

    private static List<GeneratedFile> ParseFileBlocks(string response)
    {
        var files = new List<GeneratedFile>();
        var rx = new Regex(@"<<<FILE:(?<path>[^>]+)>>>(?<body>.*?)<<<END_FILE>>>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        foreach (Match m in rx.Matches(response))
        {
            string path = m.Groups["path"].Value.Trim().Replace('/', Path.DirectorySeparatorChar);
            string body = StripFence(m.Groups["body"].Value);
            if (!string.IsNullOrWhiteSpace(path) && !string.IsNullOrWhiteSpace(body))
                files.Add(new GeneratedFile(path, body));
        }
        return files;
    }

    private static string StripFence(string text)
    {
        string t = text.Trim();
        if (!t.StartsWith("```")) return t;
        int nl = t.IndexOf('\n');
        if (nl >= 0) t = t[(nl + 1)..];
        int end = t.LastIndexOf("```", StringComparison.Ordinal);
        if (end >= 0) t = t[..end];
        return t.Trim();
    }

    private static string NormalizeGeneratedPath(string relative, string packageName)
    {
        relative = relative.Trim().TrimStart('\\', '/').Replace('/', Path.DirectorySeparatorChar);
        if (relative.Equals("pom.xml", StringComparison.OrdinalIgnoreCase)) return "pom.xml";
        if (relative.EndsWith(".java", StringComparison.OrdinalIgnoreCase))
        {
            if (relative.StartsWith("src" + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) return relative;
            string packagePath = packageName.Replace('.', Path.DirectorySeparatorChar);
            return Path.Combine("src", "main", "java", packagePath, Path.GetFileName(relative));
        }
        return Path.Combine("migration-extra", relative);
    }

    private static void WriteBaseMavenProject(string outputDir, string appName, string packageName)
    {
        Directory.CreateDirectory(Path.Combine(outputDir, "src", "main", "java", packageName.Replace('.', Path.DirectorySeparatorChar)));
        EnsurePom(outputDir, appName, packageName);
    }

    private static void EnsurePom(string outputDir, string appName, string packageName)
    {
        string pom = Path.Combine(outputDir, "pom.xml");
        if (File.Exists(pom)) return;
        string artifact = ToPackagePart(appName);
        File.WriteAllText(pom, $"""
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>
  <groupId>migrated</groupId>
  <artifactId>{artifact}</artifactId>
  <version>1.0.0</version>
  <properties>
    <maven.compiler.release>21</maven.compiler.release>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
  </properties>
  <dependencies>
    <dependency><groupId>org.xerial</groupId><artifactId>sqlite-jdbc</artifactId><version>3.46.1.0</version></dependency>
    <dependency><groupId>com.fasterxml.jackson.core</groupId><artifactId>jackson-databind</artifactId><version>2.17.2</version></dependency>
    <dependency><groupId>org.apache.pdfbox</groupId><artifactId>pdfbox</artifactId><version>3.0.3</version></dependency>
    <dependency><groupId>org.apache.commons</groupId><artifactId>commons-csv</artifactId><version>1.11.0</version></dependency>
    <dependency><groupId>org.junit.jupiter</groupId><artifactId>junit-jupiter</artifactId><version>5.11.0</version><scope>test</scope></dependency>
  </dependencies>
  <build>
    <plugins>
      <plugin><groupId>org.apache.maven.plugins</groupId><artifactId>maven-compiler-plugin</artifactId><version>3.13.0</version></plugin>
      <plugin><groupId>org.apache.maven.plugins</groupId><artifactId>maven-surefire-plugin</artifactId><version>3.5.0</version></plugin>
      <plugin>
        <groupId>org.apache.maven.plugins</groupId><artifactId>maven-jar-plugin</artifactId><version>3.4.2</version>
        <configuration><archive><manifest><mainClass>{packageName}.{appName}</mainClass></manifest></archive></configuration>
      </plugin>
    </plugins>
  </build>
</project>
""", new UTF8Encoding(false));
    }

    private static void EnsureMainClass(string outputDir, string appName, string packageName)
    {
        string packagePath = packageName.Replace('.', Path.DirectorySeparatorChar);
        string path = Path.Combine(outputDir, "src", "main", "java", packagePath, appName + ".java");
        if (File.Exists(path)) return;
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        File.WriteAllText(path, $$"""
package {{packageName}};

import javax.swing.*;

public class {{appName}} {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null,
            "Python migration scaffold created. Continue automatic repair/migration from the generated project.",
            "{{appName}}", JOptionPane.INFORMATION_MESSAGE));
    }
}
""", new UTF8Encoding(false));
    }

    private static string SanitizeJavaIdentifier(string value)
    {
        string s = Regex.Replace(value, @"[^A-Za-z0-9_$]", "_");
        if (string.IsNullOrEmpty(s)) return "MigratedPythonApp";
        if (char.IsDigit(s[0])) s = "App_" + s;
        return s;
    }

    private static string ToPackagePart(string value)
    {
        string s = Regex.Replace(value.ToLowerInvariant(), @"[^a-z0-9_]", "_");
        if (string.IsNullOrWhiteSpace(s)) s = "app";
        if (char.IsDigit(s[0])) s = "app_" + s;
        return s;
    }
}
