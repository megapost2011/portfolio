using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace JavaAutoRepairBuilder;

public sealed record JavaExtractionResult(
    bool Success,
    string Code,
    string Strategy,
    int Score,
    string Diagnostic);

/// <summary>
/// LLMごとの出力癖に依存せず、説明文/Markdown/FILEブロック/JSON/<think>付き応答から
/// Javaソース候補を救出する。文字列だけで「Javaではない」と即停止しないための層。
/// </summary>
public static class JavaResponseExtractor
{
    private static readonly Regex FileBlockRegex = new(
        @"<<<FILE:(?<name>[^>]+)>>>(?<code>[\s\S]*?)<<<END_FILE>>>",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex FenceRegex = new(
        @"```(?<lang>java|[A-Za-z0-9_+.-]*)\s*\r?\n(?<code>[\s\S]*?)```",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex TypeRegex = new(
        @"\b(?:public\s+|protected\s+|private\s+|abstract\s+|final\s+|sealed\s+|non-sealed\s+|static\s+)*" +
        @"(?:class|interface|enum|record)\s+(?<name>[A-Za-z_$][A-Za-z0-9_$]*)\b",
        RegexOptions.Compiled);

    public static JavaExtractionResult Extract(string raw, string expectedFilePath)
    {
        string expectedName = Path.GetFileNameWithoutExtension(expectedFilePath);
        if (string.IsNullOrWhiteSpace(raw))
            return new(false, "", "empty", 0, "AI response was empty.");

        string text = Normalize(raw);
        var candidates = new List<(string Code, string Strategy, int Score)>();

        AddFileBlocks(text, expectedFilePath, expectedName, candidates);
        AddJsonEmbeddedCandidates(text, expectedName, candidates);
        AddFencedBlocks(text, expectedName, candidates);
        AddWholeResponseCandidate(text, expectedName, candidates);
        AddLexicalCandidates(text, expectedName, candidates);

        var best = candidates
            .Select(c => (c.Code, c.Strategy, Score: c.Score + ScoreJava(c.Code, expectedName)))
            .Where(c => LooksPlausible(c.Code, expectedName))
            .OrderByDescending(c => c.Score)
            .ThenByDescending(c => c.Code.Length)
            .FirstOrDefault();

        if (string.IsNullOrWhiteSpace(best.Code))
        {
            return new(false, "", "none", 0,
                "No plausible Java source candidate could be extracted. Raw response should be retained for retry.");
        }

        bool structuredContainer = best.Strategy.StartsWith("FILE_BLOCK", StringComparison.OrdinalIgnoreCase)
            || best.Strategy.StartsWith("MARKDOWN_FENCE", StringComparison.OrdinalIgnoreCase)
            || best.Strategy.StartsWith("JSON_", StringComparison.OrdinalIgnoreCase);
        string cleaned = structuredContainer ? best.Code.Trim() : TrimToJavaUnit(best.Code, expectedName);
        if (!LooksPlausible(cleaned, expectedName))
        {
            return new(false, "", best.Strategy, best.Score,
                "A candidate was found but failed the structural Java sanity check.");
        }

        return new(true, cleaned.Trim(), best.Strategy, best.Score,
            $"Extracted by {best.Strategy}; score={best.Score}; chars={cleaned.Length}");
    }

    private static string Normalize(string raw)
    {
        string text = raw.Replace("\uFEFF", "").Trim();
        text = Regex.Replace(text, @"<think>[\s\S]*?</think>", "", RegexOptions.IgnoreCase);
        text = Regex.Replace(text, @"<analysis>[\s\S]*?</analysis>", "", RegexOptions.IgnoreCase);
        return text.Trim();
    }

    private static void AddFileBlocks(string text, string expectedFilePath, string expectedName,
        List<(string Code, string Strategy, int Score)> list)
    {
        string expectedFile = Path.GetFileName(expectedFilePath);
        foreach (Match m in FileBlockRegex.Matches(text))
        {
            string name = m.Groups["name"].Value.Trim().Replace('\\', '/');
            string code = m.Groups["code"].Value.Trim();
            int bonus = name.EndsWith(expectedFile, StringComparison.OrdinalIgnoreCase) ? 120 :
                        name.EndsWith(expectedName + ".java", StringComparison.OrdinalIgnoreCase) ? 100 : 30;
            list.Add((code, "FILE_BLOCK", bonus));
        }
    }

    private static void AddJsonEmbeddedCandidates(string text, string expectedName,
        List<(string Code, string Strategy, int Score)> list)
    {
        if (!(text.StartsWith("{") || text.StartsWith("["))) return;
        try
        {
            using var doc = JsonDocument.Parse(text);
            WalkJson(doc.RootElement, expectedName, list, 0);
        }
        catch
        {
            // JSONらしく見えて壊れている応答もあるので、ここで失敗しても他戦略へ進む。
        }
    }

    private static void WalkJson(JsonElement el, string expectedName,
        List<(string Code, string Strategy, int Score)> list, int depth)
    {
        if (depth > 8) return;
        switch (el.ValueKind)
        {
            case JsonValueKind.String:
                string? s = el.GetString();
                if (!string.IsNullOrWhiteSpace(s) &&
                    (s.Contains("class ") || s.Contains("interface ") || s.Contains("record ") || s.Contains("enum ")))
                    list.Add((s, "JSON_STRING", 45));
                break;
            case JsonValueKind.Object:
                foreach (var p in el.EnumerateObject())
                {
                    int bonus = p.NameEquals("code") || p.NameEquals("source") || p.NameEquals("content") ||
                                p.NameEquals("response") || p.NameEquals("result") || p.NameEquals("text") ? 25 : 0;
                    if (p.Value.ValueKind == JsonValueKind.String)
                    {
                        string? v = p.Value.GetString();
                        if (!string.IsNullOrWhiteSpace(v) &&
                            (v.Contains("class ") || v.Contains("interface ") || v.Contains("record ") || v.Contains("enum ")))
                            list.Add((v, "JSON_PROPERTY:" + p.Name, 45 + bonus));
                    }
                    WalkJson(p.Value, expectedName, list, depth + 1);
                }
                break;
            case JsonValueKind.Array:
                foreach (var item in el.EnumerateArray()) WalkJson(item, expectedName, list, depth + 1);
                break;
        }
    }

    private static void AddFencedBlocks(string text, string expectedName,
        List<(string Code, string Strategy, int Score)> list)
    {
        foreach (Match m in FenceRegex.Matches(text))
        {
            string lang = m.Groups["lang"].Value.Trim();
            string code = m.Groups["code"].Value.Trim();
            int bonus = lang.Equals("java", StringComparison.OrdinalIgnoreCase) ? 85 : 55;
            list.Add((code, "MARKDOWN_FENCE" + (lang.Length > 0 ? ":" + lang : ""), bonus));
        }
    }

    private static void AddWholeResponseCandidate(string text, string expectedName,
        List<(string Code, string Strategy, int Score)> list)
    {
        if (text.Contains("class ") || text.Contains("interface ") || text.Contains("record ") || text.Contains("enum "))
            list.Add((text, "WHOLE_RESPONSE", 10));
    }

    private static void AddLexicalCandidates(string text, string expectedName,
        List<(string Code, string Strategy, int Score)> list)
    {
        foreach (Match m in TypeRegex.Matches(text))
        {
            string typeName = m.Groups["name"].Value;
            int brace = FindNextCodeBrace(text, m.Index + m.Length);
            if (brace < 0) continue;
            int end = FindMatchingBrace(text, brace);
            if (end < 0) continue;

            int start = FindCompilationUnitStart(text, m.Index);
            string code = text[start..(end + 1)].Trim();
            int bonus = typeName.Equals(expectedName, StringComparison.Ordinal) ? 95 : 50;
            list.Add((code, "LEXICAL_TYPE:" + typeName, bonus));
        }
    }

    private static int ScoreJava(string code, string expectedName)
    {
        int score = 0;
        if (Regex.IsMatch(code, @"(?m)^\s*package\s+[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*\s*;")) score += 15;
        if (Regex.IsMatch(code, @"(?m)^\s*import\s+")) score += 5;
        if (Regex.IsMatch(code, @"\b(?:class|interface|enum|record)\s+" + Regex.Escape(expectedName) + @"\b")) score += 60;
        if (Regex.IsMatch(code, @"\bpublic\s+(?:final\s+|abstract\s+|sealed\s+)?(?:class|interface|enum|record)\s+" + Regex.Escape(expectedName) + @"\b")) score += 45;
        if (code.Contains("```")) score -= 35;
        if (Regex.IsMatch(code, @"(?im)^\s*(Here is|修正|説明|変更点|以下|回答)")) score -= 25;
        if (BracesBalanced(code)) score += 25; else score -= 80;
        return score;
    }

    public static bool LooksPlausible(string code, string expectedName)
    {
        if (string.IsNullOrWhiteSpace(code) || code.Length < 20) return false;
        if (code.Contains("```")) return false;

        string fileName = expectedName + ".java";
        if (fileName.Equals("module-info.java", StringComparison.OrdinalIgnoreCase))
            return code.Contains("module ") && BracesBalanced(code);
        if (fileName.Equals("package-info.java", StringComparison.OrdinalIgnoreCase))
            return code.Contains("package ");

        bool hasType = Regex.IsMatch(code, @"\b(?:class|interface|enum|record)\s+[A-Za-z_$][A-Za-z0-9_$]*\b");
        if (!hasType) return false;
        bool hasExpectedType = Regex.IsMatch(code,
            @"\b(?:class|interface|enum|record)\s+" + Regex.Escape(expectedName) + @"\b");
        if (!hasExpectedType) return false;
        return BracesBalanced(code);
    }

    private static string TrimToJavaUnit(string candidate, string expectedName)
    {
        string text = candidate.Trim();
        if (text.StartsWith("```"))
        {
            int nl = text.IndexOf('\n');
            if (nl >= 0) text = text[(nl + 1)..];
            int endFence = text.LastIndexOf("```", StringComparison.Ordinal);
            if (endFence >= 0) text = text[..endFence];
        }

        Match target = Regex.Match(text,
            @"\b(?:public\s+|protected\s+|private\s+|abstract\s+|final\s+|sealed\s+|non-sealed\s+|static\s+)*" +
            @"(?:class|interface|enum|record)\s+" + Regex.Escape(expectedName) + @"\b");
        if (!target.Success) target = TypeRegex.Match(text);
        if (!target.Success) return text.Trim();

        int brace = FindNextCodeBrace(text, target.Index + target.Length);
        int close = brace >= 0 ? FindMatchingBrace(text, brace) : -1;
        if (close < 0) return text.Trim();
        int start = FindCompilationUnitStart(text, target.Index);
        return text[start..(close + 1)].Trim();
    }

    private static int FindCompilationUnitStart(string text, int typeIndex)
    {
        string before = text[..typeIndex];
        var package = Regex.Matches(before, @"(?m)^\s*package\s+[^;\r\n]+;\s*$").Cast<Match>().LastOrDefault();
        if (package != null) return package.Index;

        var import = Regex.Matches(before, @"(?m)^\s*import\s+[^;\r\n]+;\s*$").Cast<Match>().FirstOrDefault();
        if (import != null) return import.Index;

        // classの直前に付いたアノテーション/Javadocをなるべく保持する。
        int lineStart = before.LastIndexOf('\n');
        return lineStart < 0 ? 0 : lineStart + 1;
    }

    private static int FindNextCodeBrace(string text, int start)
    {
        var state = new LexState();
        for (int i = 0; i < text.Length; i++)
        {
            if (!AdvanceState(text, ref i, state)) continue;
            if (i >= start && state.Mode == LexMode.Normal && text[i] == '{') return i;
        }
        return -1;
    }

    private static int FindMatchingBrace(string text, int openIndex)
    {
        int depth = 0;
        var state = new LexState();
        for (int i = 0; i < text.Length; i++)
        {
            if (!AdvanceState(text, ref i, state)) continue;
            if (i < openIndex || state.Mode != LexMode.Normal) continue;
            if (text[i] == '{') depth++;
            else if (text[i] == '}')
            {
                depth--;
                if (depth == 0) return i;
                if (depth < 0) return -1;
            }
        }
        return -1;
    }

    public static bool BracesBalanced(string text)
    {
        int depth = 0;
        var state = new LexState();
        for (int i = 0; i < text.Length; i++)
        {
            if (!AdvanceState(text, ref i, state)) continue;
            if (state.Mode != LexMode.Normal) continue;
            if (text[i] == '{') depth++;
            else if (text[i] == '}')
            {
                depth--;
                if (depth < 0) return false;
            }
        }
        return depth == 0 && state.Mode is LexMode.Normal or LexMode.LineComment;
    }

    private enum LexMode { Normal, LineComment, BlockComment, String, Char, TextBlock }
    private sealed class LexState { public LexMode Mode = LexMode.Normal; public bool Escape; }

    /// <summary>返値trueは現在文字を構文文字として評価してよいことを表す。</summary>
    private static bool AdvanceState(string text, ref int i, LexState s)
    {
        char c = text[i];
        char n = i + 1 < text.Length ? text[i + 1] : '\0';

        switch (s.Mode)
        {
            case LexMode.Normal:
                if (c == '/' && n == '/') { s.Mode = LexMode.LineComment; i++; return false; }
                if (c == '/' && n == '*') { s.Mode = LexMode.BlockComment; i++; return false; }
                if (c == '"' && i + 2 < text.Length && text[i + 1] == '"' && text[i + 2] == '"')
                { s.Mode = LexMode.TextBlock; i += 2; return false; }
                if (c == '"') { s.Mode = LexMode.String; s.Escape = false; return false; }
                if (c == '\'') { s.Mode = LexMode.Char; s.Escape = false; return false; }
                return true;

            case LexMode.LineComment:
                if (c == '\n') s.Mode = LexMode.Normal;
                return false;

            case LexMode.BlockComment:
                if (c == '*' && n == '/') { s.Mode = LexMode.Normal; i++; }
                return false;

            case LexMode.String:
                if (s.Escape) { s.Escape = false; return false; }
                if (c == '\\') { s.Escape = true; return false; }
                if (c == '"') s.Mode = LexMode.Normal;
                return false;

            case LexMode.Char:
                if (s.Escape) { s.Escape = false; return false; }
                if (c == '\\') { s.Escape = true; return false; }
                if (c == '\'') s.Mode = LexMode.Normal;
                return false;

            case LexMode.TextBlock:
                if (c == '"' && i + 2 < text.Length && text[i + 1] == '"' && text[i + 2] == '"')
                { s.Mode = LexMode.Normal; i += 2; }
                return false;
        }
        return false;
    }
}
