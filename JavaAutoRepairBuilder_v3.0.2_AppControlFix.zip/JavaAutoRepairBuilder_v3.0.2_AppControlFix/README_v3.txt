Java Auto Repair Builder v3.0 - Universal LLM Repair Loop
==========================================================

目的
----
Ollama上のLLM（gpt-oss / Qwen / Gemma / DeepSeek 等）が、修正版Javaを
どのような形式で返しても、応答形式だけを理由にPipelineを停止させない。

v3.0の変更点
--------------
1. JavaResponseExtractor.cs を追加
   - <<<FILE:...>>> ... <<<END_FILE>>>
   - ```java ... ``` / 言語名なしコードフェンス
   - JSONの code/source/content/response/result/text
   - <think>...</think> / <analysis>...</analysis>
   - 説明文 + Java全文
   - package/import/public class 形式
   を順番に解析し、最も安全なJava候補を採用する。

2. 「AI応答がJavaソースとして不正」で即停止しない
   - RAW応答を .java-auto-repair-raw に保存
   - 同じファイルへ最大4回AI再要求
   - 抽出失敗、空応答、元ソースと同一、省略コードは再試行
   - 4回失敗してもプロジェクトPipeline自体は停止せず次ループへ進む

3. 同一エラー3回で停止を廃止
   - 同じエラーが継続した場合 [ESCALATE] としてプロンプトを強化
   - 成功 / STOP / Max repair loops まで継続

4. 修復対象ファイルのフォールバック探索
   - Foo.java 名
   - cannot find symbol
   - package ... does not exist
   - 1ファイルJavaプロジェクト
   - 最近更新されたJava
   から候補を選択する。

5. 安全対策
   - 修正前バックアップを .java-auto-repair-backup に保存
   - Javaのコメント/文字列/char/text blockを考慮して {} の整合性を確認
   - 対象ファイル名と同名の class/interface/enum/record を要求
   - "... existing code ..." や「以下省略」などの欠落応答は採用しない
   - AIのRAW応答を常時保存するため、失敗原因を後から確認できる

使い方
------
1. dotnet build
2. dotnet run
3. Java Project を選択
4. Load Models
5. 任意のOllamaモデルを選択
6. Max repair loops を必要に応じて設定（初期値30）
7. AUTO BUILD / REPAIR

重要
----
「どのLLMでも対応」は、LLMの応答フォーマット差を吸収するという意味です。
モデル自体が正しいJava修正を生成できない場合でも停止せず再試行しますが、
最終的な修復成功そのものを保証するものではありません。

依存ライブラリを使うJavaは、可能ならpom.xmlを持つMavenプロジェクトとして
修復してください。単純javacモードでは外部JARのclasspathが自動解決されません。
