$ErrorActionPreference = 'Continue'
Set-Location $PSScriptRoot

Write-Host "============================================"
Write-Host " Java Auto Repair Builder v3.0.2 AppControl"
Write-Host "============================================"
Write-Host ""

Write-Host "--- CLEAN ---"
dotnet clean
Write-Host ""
Write-Host "--- BUILD ---"
dotnet build
if ($LASTEXITCODE -ne 0) {
    Write-Host "BUILD FAILED"
    Read-Host "Press Enter"
    exit $LASTEXITCODE
}

$dll = Join-Path $PSScriptRoot 'bin\Debug\net8.0-windows\JavaAutoRepairBuilder.dll'
Write-Host ""
Write-Host "--- RUN DLL THROUGH DOTNET HOST ---"
Write-Host "DLL: $dll"
if (!(Test-Path $dll)) {
    Write-Host "DLL NOT FOUND"
    Read-Host "Press Enter"
    exit 2
}

dotnet "$dll"
$code = $LASTEXITCODE
Write-Host ""
Write-Host "dotnet DLL exit code: $code"

$base = Split-Path $dll
foreach ($name in @('startup_crash.log','startup_trace.log')) {
    $p = Join-Path $base $name
    if (Test-Path $p) {
        Write-Host ""
        Write-Host "--- $name ---"
        Get-Content $p -Tail 100
    }
}

Read-Host "Press Enter"
